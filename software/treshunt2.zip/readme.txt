Treasure Hunt
~~~~~~~~~~~~~
This is a text adventure where you have to find treasure. It is based on an earlier text adventure I made in Perl back in 2008.

The game requires a Z-Code interpreter. You can find one at http://www.ifwiki.org/index.php/Interpreter

The source code is included in the archive.

By Cameron Cawley